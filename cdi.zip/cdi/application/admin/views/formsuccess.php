<html>
<head>
    <title>Моя форма</title>
</head>
<body>

<h3>Ваша форма была успешно отправлена!</h3>

<p><?php echo anchor('admin/form', 'Попробуйте снова!'); ?></p>

</body>
</html>
